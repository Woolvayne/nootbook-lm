"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Clapperboard, Plug, Sparkles } from "lucide-react";
import clsx from "clsx";

const LINKS = [
  { href: "/studio", label: "Studio", icon: Clapperboard },
  { href: "/connect", label: "KI-Assistenten", icon: Plug },
];

export default function SiteNav() {
  const pathname = usePathname();
  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8">
        <Link
          href="/"
          className="group flex items-center gap-2.5 font-display text-lg font-bold tracking-tight"
        >
          <span className="ring-conic flex h-8 w-8 items-center justify-center rounded-lg">
            <Sparkles className="h-4 w-4 text-white" strokeWidth={2.4} />
          </span>
          <span>
            NARRATO
            <span className="text-gradient">.</span>
          </span>
        </Link>

        <nav className="glass flex items-center gap-1 rounded-full p-1.5">
          {LINKS.map(({ href, label, icon: Icon }) => {
            const active = pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={clsx(
                  "flex items-center gap-2 rounded-full px-3.5 py-2 text-sm font-medium transition-all sm:px-5",
                  active
                    ? "bg-white/10 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]"
                    : "text-mist hover:text-white",
                )}
              >
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{label}</span>
              </Link>
            );
          })}
          <Link
            href="/studio"
            className="ml-1 hidden rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-violet-500/25 transition-transform hover:scale-[1.03] active:scale-95 md:block"
          >
            Video erstellen
          </Link>
        </nav>
      </div>
    </header>
  );
}
