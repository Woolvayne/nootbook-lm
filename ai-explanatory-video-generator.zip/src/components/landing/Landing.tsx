"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight,
  AudioLines,
  Bot,
  Clapperboard,
  Download,
  FileText,
  Image as ImageIcon,
  KeyRound,
  MousePointerClick,
  Scissors,
  Sparkles,
  Wand2,
} from "lucide-react";

const fadeUp = {
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-80px" },
  transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] as const },
};

function pn(prompt: string, seed: number, w = 480, h = 270) {
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(
    prompt,
  )}?width=${w}&height=${h}&seed=${seed}&nologo=true&model=flux`;
}

const MARQUEE_A = [
  "futuristic classroom with a glowing holographic brain, cinematic film still, dramatic light",
  "the water cycle explained as floating magical islands, modern flat illustration",
  "roman colosseum at golden hour, epic cinematic film still",
  "inside a human cell, glowing organelles, pixar style 3d render",
  "solar system as miniature model on a wooden desk, macro photography",
  "neural network as a starry night sky, painterly impressionism",
];
const MARQUEE_B = [
  "honeybee colony as a tiny glowing robot factory, 3d render",
  "photosynthesis as a glowing forest factory, anime key visual",
  "deep sea bioluminescent creatures, nature documentary still",
  "the moon landing reimagined in soft watercolor",
  "coffee chemistry, floating molecular structures, dark macro photo",
  "stock market charts as a neon city skyline, digital art",
];

function MarqueeRow({ prompts, reverse }: { prompts: string[]; reverse?: boolean }) {
  const doubled = [...prompts, ...prompts];
  return (
    <div className="mask-fade-x overflow-hidden">
      <div
        className={`flex w-max gap-4 pr-4 ${
          reverse ? "animate-marquee-right" : "animate-marquee-left"
        }`}
      >
        {doubled.map((p, i) => (
          <div
            key={i}
            className="group relative h-36 w-64 shrink-0 overflow-hidden rounded-xl border border-white/8 bg-ink-3 sm:h-44 sm:w-80"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={pn(p, 100 + i)}
              alt="KI-generiertes Beispielbild"
              loading="lazy"
              className="h-full w-full object-cover opacity-80 transition duration-700 group-hover:scale-105 group-hover:opacity-100"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent" />
          </div>
        ))}
      </div>
    </div>
  );
}

const STEPS = [
  {
    n: "01",
    icon: MousePointerClick,
    title: "Thema eintippen",
    text: "Von „Quantenphysik“ bis „Wie funktioniert ein Kredit?“ — ein Satz genügt. Mistral API-Key eintragen (kostenlos), Kreativität entfesseln.",
  },
  {
    n: "02",
    icon: FileText,
    title: "Drehbuch entsteht",
    text: "Mistral schreibt ein gespanntes Skript: Hook, dramaturgischer Bogen, Fazit — plus eine kinoreife Bildbeschreibung pro Szene.",
  },
  {
    n: "03",
    icon: ImageIcon,
    title: "Bilder & Stimme",
    text: "Pollinations generiert zu jeder Szene ein Bild im Wunschstil und vertont den Erzähltext mit einer KI-Stimme deiner Wahl.",
  },
  {
    n: "04",
    icon: Clapperboard,
    title: "Film & Download",
    text: "Der Auto-Schnitt in deinem Browser fügt alles zusammen: Ken-Burns, Untertitel, Übergänge. Ein Klick — fertige WebM-Datei.",
  },
];

const FEATURES = [
  {
    icon: Wand2,
    title: "Story-Drehbuch von Mistral",
    text: "Kein langweiliger Faktenvortrag: Hook, Spannungsbogen und Erzählstimme wie bei den großen Erklärkanälen.",
  },
  {
    icon: ImageIcon,
    title: "6 Bildstile",
    text: "Kinoreif, Flat-Illustration, Aquarell, 3D-Render, Fotorealismus oder Anime — pro Projekt wählbar.",
  },
  {
    icon: AudioLines,
    title: "Vertonung inklusive",
    text: "Sechs Sprecherstimmen von warm bis tief. Komplett kostenlos, ohne eigenen TTS-Schlüssel.",
  },
  {
    icon: Scissors,
    title: "Auto-Schnitt im Browser",
    text: "Echtzeit-Komposition auf Canvas: Ken-Burns-Bewegung, Untertitel, Blenden und Fortschrittsbalken.",
  },
  {
    icon: Download,
    title: "Download & Projekt-Archiv",
    text: "Fertiger Film als WebM-Datei. Projekte werden gespeichert und lassen sich jederzeit neu rendern.",
  },
  {
    icon: Bot,
    title: "API für KI-Assistenten",
    text: "Custom GPTs, Claude & Co. können per REST-API eigene Erklärvideos auslösen — mit einem einzigen Request.",
  },
];

function OpenAPISnippet() {
  const code = `curl -X POST https://deine-domain/api/v1/generate \\
  -H "x-api-key: nrto_..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "topic": "Warum leuchten Glühwürmchen?",
    "style": "cinematic",
    "voice": "onyx",
    "sceneCount": 5
  }'`;
  return (
    <div className="glass overflow-hidden rounded-2xl">
      <div className="flex items-center gap-2 border-b border-white/5 px-5 py-3">
        <span className="h-3 w-3 rounded-full bg-red-400/70" />
        <span className="h-3 w-3 rounded-full bg-amber-400/70" />
        <span className="h-3 w-3 rounded-full bg-emerald-400/70" />
        <span className="ml-2 text-xs text-mist">narrato-api.sh</span>
      </div>
      <pre className="overflow-x-auto p-5 text-[13px] leading-relaxed text-violet-200/90">
        <code>{code}</code>
      </pre>
    </div>
  );
}

export default function Landing() {
  return (
    <main>
      {/* ---------- HERO ---------- */}
      <section className="relative overflow-hidden px-5 pt-40 pb-24 sm:px-8 sm:pt-48">
        <div className="mx-auto max-w-5xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass mx-auto mb-8 flex w-fit items-center gap-2 rounded-full px-4 py-2 text-xs font-medium tracking-wide text-mist"
          >
            <Sparkles className="h-3.5 w-3.5 text-violet-300" />
            KI-ERKLÄRVIDEO-STUDIO · KOSTENLOSE PIPELINE
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.08 }}
            className="font-display text-[clamp(2.6rem,8vw,5.5rem)] leading-[1.02] font-bold tracking-tight text-balance"
          >
            Vom Thema zum
            <br />
            <span className="text-gradient">fertigen Erklärfilm.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.18 }}
            className="mx-auto mt-7 max-w-2xl text-base leading-relaxed text-mist sm:text-lg"
          >
            Wie NotebookLM — nur mit Video. Mistral schreibt das Drehbuch,
            Pollinations malt jede Szene und leiht ihr eine Stimme, und dein
            Browser schneidet daraus automatisch einen Erklärfilm mit Untertiteln.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.28 }}
            className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row"
          >
            <Link
              href="/studio"
              className="group flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 px-8 py-4 text-sm font-semibold text-white shadow-xl shadow-violet-500/30 transition-transform hover:scale-[1.03] active:scale-95"
            >
              Studio starten
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              href="/connect"
              className="glass flex items-center gap-2 rounded-full px-8 py-4 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              <Bot className="h-4 w-4 text-fuchsia-300" />
              Mit KI-Assistenten verbinden
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.45 }}
            className="mx-auto mt-14 grid max-w-2xl grid-cols-3 gap-6"
          >
            {[
              ["~3 Min.", "bis zum fertigen Film"],
              ["0 €", "Bilder & Sprache inklusive"],
              ["100 %", "im Browser geschnitten"],
            ].map(([v, l]) => (
              <div key={l} className="text-center">
                <div className="font-display text-2xl font-bold sm:text-3xl">
                  {v}
                </div>
                <div className="mt-1 text-xs text-mist">{l}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Live-Marquee */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-20 space-y-4"
        >
          <MarqueeRow prompts={MARQUEE_A} />
          <MarqueeRow prompts={MARQUEE_B} reverse />
          <p className="text-center text-xs text-mist/70">
            Alle Bilder oben: live von Pollinations generiert — genau so sieht dein Video aus.
          </p>
        </motion.div>
      </section>

      {/* ---------- STEPS ---------- */}
      <section className="px-5 py-24 sm:px-8">
        <div className="mx-auto max-w-6xl">
          <motion.div {...fadeUp} className="mb-14 max-w-xl">
            <div className="mb-3 text-xs font-semibold tracking-[0.25em] text-violet-300">
              DER WORKFLOW
            </div>
            <h2 className="font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl">
              Vier Schritte. <span className="text-gradient">Null Schnittprogramm.</span>
            </h2>
          </motion.div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <motion.div
                key={s.n}
                {...fadeUp}
                transition={{ ...fadeUp.transition, delay: i * 0.08 }}
                className="glass group relative overflow-hidden rounded-2xl p-6 transition-colors hover:bg-white/[0.06]"
              >
                <div className="absolute -top-4 -right-2 font-display text-[88px] font-bold text-white/[0.04] transition-colors group-hover:text-white/[0.07]">
                  {s.n}
                </div>
                <s.icon className="mb-5 h-6 w-6 text-violet-300" />
                <h3 className="font-display text-lg font-semibold">{s.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-mist">{s.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- FEATURES ---------- */}
      <section className="px-5 py-24 sm:px-8">
        <div className="mx-auto max-w-6xl">
          <motion.div {...fadeUp} className="mb-14 max-w-xl">
            <div className="mb-3 text-xs font-semibold tracking-[0.25em] text-fuchsia-300">
              ALLES DRIN
            </div>
            <h2 className="font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl">
              Ein Studio. <span className="text-gradient">Komplette Crew.</span>
            </h2>
          </motion.div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f, i) => (
              <motion.div
                key={f.title}
                {...fadeUp}
                transition={{ ...fadeUp.transition, delay: (i % 3) * 0.08 }}
                className="group relative overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-b from-white/[0.04] to-transparent p-7"
              >
                <div className="absolute -top-16 -right-16 h-40 w-40 rounded-full bg-violet-500/10 blur-2xl transition-opacity duration-500 group-hover:opacity-100" />
                <f.icon className="mb-5 h-6 w-6 text-fuchsia-300" />
                <h3 className="font-display text-lg font-semibold">{f.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-mist">{f.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- API ---------- */}
      <section className="px-5 py-24 sm:px-8">
        <div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-2">
          <motion.div {...fadeUp}>
            <div className="mb-3 text-xs font-semibold tracking-[0.25em] text-orange-300">
              FÜR KI-ASSISTENTEN
            </div>
            <h2 className="font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl">
              Lass <span className="text-gradient">deinen Assistenten</span> Videos bauen.
            </h2>
            <p className="mt-5 max-w-lg leading-relaxed text-mist">
              Ein REST-Endpunkt, ein API-Key — und Custom GPTs, Claude-Projekte
              oder dein eigener Agent erzeugen komplette Erklärvideos mit einem
              Request. Inklusive OpenAPI-Schema zum Einklinken in GPT Actions.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/connect"
                className="group flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-semibold text-ink transition-transform hover:scale-[1.03] active:scale-95"
              >
                <KeyRound className="h-4 w-4" />
                API-Key erstellen
              </Link>
              <Link
                href="/connect#docs"
                className="glass flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold transition-colors hover:bg-white/10"
              >
                Dokumentation
              </Link>
            </div>
          </motion.div>
          <motion.div {...fadeUp} transition={{ ...fadeUp.transition, delay: 0.1 }}>
            <OpenAPISnippet />
          </motion.div>
        </div>
      </section>

      {/* ---------- FINAL CTA ---------- */}
      <section className="px-5 py-28 sm:px-8">
        <motion.div
          {...fadeUp}
          className="relative mx-auto max-w-4xl overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-ink-3 to-ink-2 px-8 py-16 text-center sm:py-20"
        >
          <div className="animate-pulse-glow absolute -top-24 left-1/2 h-64 w-[120%] -translate-x-1/2 rounded-full bg-violet-500/15 blur-3xl" />
          <h2 className="relative font-display text-3xl font-bold tracking-tight text-balance sm:text-5xl">
            Dein erstes Erklärvideo wartet.
          </h2>
          <p className="relative mx-auto mt-4 max-w-md text-mist">
            Thema rein, Film raus. In etwa drei Minuten, komplett im Browser.
          </p>
          <Link
            href="/studio"
            className="group relative mt-9 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 px-9 py-4 text-sm font-semibold text-white shadow-xl shadow-violet-500/30 transition-transform hover:scale-[1.03] active:scale-95"
          >
            Jetzt kostenlos starten
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </motion.div>
      </section>
    </main>
  );
}
