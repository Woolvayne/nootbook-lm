import Link from "next/link";
import { Sparkles } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-10">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-5 text-sm text-mist sm:px-8 md:flex-row">
        <div className="flex items-center gap-2 font-display font-bold text-white">
          <span className="ring-conic flex h-6 w-6 items-center justify-center rounded-md">
            <Sparkles className="h-3 w-3 text-white" />
          </span>
          NARRATO
        </div>
        <p className="text-center text-xs leading-relaxed">
          Drehbuch: Mistral AI · Bilder &amp; Stimme: Pollinations.ai (kostenlos)
          · Schnitt: Dein Browser
        </p>
        <div className="flex items-center gap-5">
          <Link href="/studio" className="transition-colors hover:text-white">
            Studio
          </Link>
          <Link href="/connect" className="transition-colors hover:text-white">
            API
          </Link>
        </div>
      </div>
    </footer>
  );
}
