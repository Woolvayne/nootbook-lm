"use client";

import { useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import {
  BadgeCheck,
  Check,
  ChevronRight,
  Clapperboard,
  Dices,
  Film,
  FolderOpen,
  KeyRound,
  Loader2,
  Play,
  RefreshCw,
  Save,
  Sparkles,
  Trash2,
  TriangleAlert,
  Wand2,
  X,
} from "lucide-react";
import clsx from "clsx";
import { STYLES, VOICES, type StudioScene } from "@/lib/types";
import { proxyImageUrl, proxyTtsUrl } from "@/lib/pollinations";
import RenderStage from "@/components/studio/RenderStage";

interface ProjectRow {
  id: string;
  title: string;
  topic: string;
  style: string;
  voice: string;
  sceneCount: number;
  createdAt: string;
}

const SAMPLE_TOPICS = [
  "Warum leuchten Glühwürmchen?",
  "Wie funktioniert ein schwarzes Loch?",
  "Die Geschichte des Geldes",
  "Was ist künstliche Intelligenz?",
];

const randomSeed = () => Math.floor(Math.random() * 999_999) + 1;

export default function StudioApp() {
  const searchParams = useSearchParams();
  const [step, setStep] = useState(1);

  // Settings
  const [apiKey, setApiKey] = useState("");
  const [keyState, setKeyState] = useState<"idle" | "checking" | "ok" | "bad">("idle");
  const [topic, setTopic] = useState("");
  const [style, setStyle] = useState<string>("cinematic");
  const [voice, setVoice] = useState<string>("nova");
  const [sceneCount, setSceneCount] = useState(5);

  // Daten
  const [videoTitle, setVideoTitle] = useState("");
  const [scenes, setScenes] = useState<StudioScene[]>([]);
  const [projectId, setProjectId] = useState<string | null>(null);
  const [projects, setProjects] = useState<ProjectRow[]>([]);

  // Status
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedTick, setSavedTick] = useState(false);
  const [voicePreviewing, setVoicePreviewing] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("narrato_mistral_key");
    if (stored) {
      setApiKey(stored);
      setKeyState("idle");
    }
    void loadProjects();
  }, []);

  const loadProjects = useCallback(async () => {
    try {
      const res = await fetch("/api/projects");
      const data = (await res.json()) as { projects?: ProjectRow[] };
      setProjects(data.projects ?? []);
    } catch {
      /* ignore */
    }
  }, []);

  // Projekt per URL laden (?project=...)
  useEffect(() => {
    const pid = searchParams.get("project");
    if (pid && !projectId) void openProject(pid);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const checkKey = async (key: string) => {
    if (!key.trim()) return;
    setKeyState("checking");
    try {
      const res = await fetch("/api/mistral/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apiKey: key.trim() }),
      });
      const data = (await res.json()) as { ok: boolean };
      setKeyState(data.ok ? "ok" : "bad");
      if (data.ok) localStorage.setItem("narrato_mistral_key", key.trim());
    } catch {
      setKeyState("bad");
    }
  };

  const generate = async () => {
    setError(null);
    if (topic.trim().length < 3) {
      setError("Bitte gib zuerst ein Thema ein.");
      return;
    }
    if (!apiKey.trim()) {
      setError("Bitte trage deinen kostenlosen Mistral API-Schlüssel ein.");
      return;
    }
    setGenerating(true);
    try {
      const res = await fetch("/api/script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic: topic.trim(),
          apiKey: apiKey.trim(),
          style,
          sceneCount,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Fehler bei der Drehbuch-Erstellung.");

      const newScenes: StudioScene[] = data.scenes.map(
        (s: { title: string; narration: string; imagePrompt: string }) => ({
          id: crypto.randomUUID(),
          title: s.title,
          narration: s.narration,
          imagePrompt: s.imagePrompt,
          seed: randomSeed(),
          imageStatus: "idle",
          audioStatus: "idle",
        }),
      );
      setVideoTitle(data.title);
      setScenes(newScenes);
      setProjectId(null);
      setStep(2);
      localStorage.setItem("narrato_mistral_key", apiKey.trim());

      // Projekt still sichern
      try {
        const saveRes = await fetch("/api/projects", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: data.title,
            topic: topic.trim(),
            style,
            voice,
            scenes: newScenes,
          }),
        });
        const saveData = (await saveRes.json()) as { id?: string };
        if (saveData.id) {
          setProjectId(saveData.id);
          void loadProjects();
        }
      } catch {
        /* Projektarchiv optional */
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unbekannter Fehler.");
    } finally {
      setGenerating(false);
    }
  };

  const openProject = async (pid: string) => {
    try {
      const res = await fetch(`/api/projects/${pid}`);
      if (!res.ok) return;
      const data = await res.json();
      setVideoTitle(data.project.title);
      setTopic(data.project.topic);
      setStyle(data.project.style);
      setVoice(data.project.voice);
      setProjectId(pid);
      setScenes(
        data.scenes.map(
          (s: {
            id: string;
            title: string;
            narration: string;
            imagePrompt: string;
            seed: number;
          }) => ({
            id: s.id,
            title: s.title,
            narration: s.narration,
            imagePrompt: s.imagePrompt,
            seed: s.seed,
            imageStatus: "idle",
            audioStatus: "idle",
          }),
        ),
      );
      setStep(2);
    } catch {
      /* ignore */
    }
  };

  const saveProject = async () => {
    if (!projectId) return;
    setSaving(true);
    try {
      await fetch(`/api/projects/${projectId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: videoTitle, style, voice, scenes }),
      });
      setSavedTick(true);
      setTimeout(() => setSavedTick(false), 2000);
      void loadProjects();
    } finally {
      setSaving(false);
    }
  };

  const deleteProject = async (pid: string) => {
    await fetch(`/api/projects/${pid}`, { method: "DELETE" });
    if (pid === projectId) setProjectId(null);
    void loadProjects();
  };

  const updateScene = (id: string, patch: Partial<StudioScene>) => {
    setScenes((prev) =>
      prev.map((s) =>
        s.id === id
          ? {
              ...s,
              ...patch,
              // Bei Textänderungen müssen Assets neu generiert werden
              ...(patch.narration !== undefined ? { audioStatus: "idle" as const } : {}),
              ...(patch.imagePrompt !== undefined || patch.seed !== undefined
                ? { imageStatus: "idle" as const }
                : {}),
            }
          : s,
      ),
    );
  };

  const previewVoice = async () => {
    if (voicePreviewing) return;
    setVoicePreviewing(true);
    try {
      const url = proxyTtsUrl(
        "Hallo! Ich bin deine Erzählerstimme und führe dich durch das Video.",
        voice,
      );
      const audio = new Audio(url);
      audio.onended = () => setVoicePreviewing(false);
      audio.onerror = () => setVoicePreviewing(false);
      await audio.play();
    } catch {
      setVoicePreviewing(false);
    }
  };

  const resetAll = () => {
    setStep(1);
    setScenes([]);
    setVideoTitle("");
    setProjectId(null);
    setError(null);
  };

  const STEPS_META = [
    { n: 1, label: "Thema & Stil", icon: Wand2 },
    { n: 2, label: "Drehbuch & Szenen", icon: Sparkles },
    { n: 3, label: "Film & Export", icon: Film },
  ];

  return (
    <div className="mx-auto max-w-6xl px-5 pt-32 pb-24 sm:px-8">
      {/* Kopf */}
      <div className="mb-10 text-center">
        <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
          Das <span className="text-gradient">Studio</span>
        </h1>
        <p className="mt-3 text-mist">
          Thema rein — Drehbuch, Bilder, Stimme und fertiger Film raus.
        </p>
      </div>

      {/* Schritte */}
      <div className="glass mx-auto mb-10 flex w-fit items-center gap-1 rounded-full p-1.5 sm:gap-2">
        {STEPS_META.map((s, i) => (
          <div key={s.n} className="flex items-center">
            <button
              onClick={() => {
                if (s.n < step) setStep(s.n);
              }}
              className={clsx(
                "flex items-center gap-2 rounded-full px-4 py-2.5 text-xs font-semibold transition-all sm:text-sm",
                step === s.n
                  ? "bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white"
                  : step > s.n
                    ? "text-white hover:bg-white/10"
                    : "text-mist/60",
              )}
            >
              <s.icon className="h-4 w-4" />
              <span className="hidden sm:inline">{s.label}</span>
              <span className="sm:hidden">{s.n}</span>
            </button>
            {i < STEPS_META.length - 1 && (
              <ChevronRight className="mx-1 h-4 w-4 text-mist/40" />
            )}
          </div>
        ))}
      </div>

      {/* Projekte */}
      {step === 1 && projects.length > 0 && (
        <div className="mb-10">
          <div className="mb-3 flex items-center gap-2 text-xs font-semibold tracking-widest text-mist uppercase">
            <FolderOpen className="h-3.5 w-3.5" /> Deine Projekte
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {projects.slice(0, 6).map((p) => (
              <div
                key={p.id}
                className="glass group flex items-center justify-between gap-3 rounded-xl px-4 py-3"
              >
                <button
                  onClick={() => openProject(p.id)}
                  className="min-w-0 flex-1 text-left"
                >
                  <div className="truncate text-sm font-semibold text-white group-hover:text-violet-200">
                    {p.title}
                  </div>
                  <div className="mt-0.5 truncate text-xs text-mist">
                    {p.sceneCount} Szenen · {new Date(p.createdAt).toLocaleDateString("de-DE")}
                  </div>
                </button>
                <button
                  onClick={() => deleteProject(p.id)}
                  className="rounded-lg p-2 text-mist/50 transition-colors hover:bg-red-500/10 hover:text-red-300"
                  title="Projekt löschen"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ------------ SCHRITT 1 ------------ */}
      {step === 1 && (
        <motion.div
          key="step1"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          {/* API-Key */}
          <div className="glass rounded-2xl p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-500/15">
                  <KeyRound className="h-5 w-5 text-violet-300" />
                </span>
                <div>
                  <div className="font-display font-semibold">Mistral API-Schlüssel</div>
                  <a
                    href="https://console.mistral.ai/api-keys"
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-violet-300 underline-offset-2 hover:underline"
                  >
                    Kostenlos holen: console.mistral.ai → API Keys
                  </a>
                </div>
              </div>
              <div className="flex min-w-0 flex-1 items-center gap-2 sm:max-w-md sm:flex-none">
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => {
                    setApiKey(e.target.value);
                    setKeyState("idle");
                  }}
                  placeholder="xxxxxxxxxxxxxxxx"
                  className="min-w-0 flex-1 rounded-xl border border-white/10 bg-ink/60 px-4 py-2.5 font-mono text-sm text-white placeholder:text-mist/40 focus:border-violet-400/60 focus:outline-none"
                />
                <button
                  onClick={() => checkKey(apiKey)}
                  disabled={keyState === "checking" || !apiKey.trim()}
                  className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-semibold transition-colors hover:bg-white/10 disabled:opacity-40"
                >
                  {keyState === "checking" ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : keyState === "ok" ? (
                    <BadgeCheck className="h-3.5 w-3.5 text-emerald-300" />
                  ) : keyState === "bad" ? (
                    <TriangleAlert className="h-3.5 w-3.5 text-red-300" />
                  ) : (
                    <Check className="h-3.5 w-3.5" />
                  )}
                  Prüfen
                </button>
              </div>
            </div>
            {keyState === "ok" && (
              <p className="mt-3 text-xs text-emerald-300">
                Schlüssel gültig und lokal gespeichert.
              </p>
            )}
            {keyState === "bad" && (
              <p className="mt-3 text-xs text-red-300">
                Schlüssel ungültig — bitte prüfe ihn auf console.mistral.ai.
              </p>
            )}
          </div>

          {/* Thema */}
          <div className="glass rounded-2xl p-6">
            <label className="mb-3 block text-xs font-semibold tracking-widest text-mist uppercase">
              Dein Thema
            </label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              rows={3}
              maxLength={400}
              placeholder="Wovon soll dein Erklärvideo handeln? z. B. „Warum ist der Himmel blau?“"
              className="w-full resize-none rounded-xl border border-white/10 bg-ink/60 p-5 font-display text-xl leading-relaxed text-white placeholder:text-mist/40 focus:border-violet-400/60 focus:outline-none sm:text-2xl"
            />
            <div className="mt-3 flex flex-wrap gap-2">
              {SAMPLE_TOPICS.map((t) => (
                <button
                  key={t}
                  onClick={() => setTopic(t)}
                  className="rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs text-mist transition-colors hover:border-violet-400/40 hover:text-white"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Stil + Optionen */}
          <div className="grid gap-6 lg:grid-cols-5">
            <div className="glass rounded-2xl p-6 lg:col-span-3">
              <label className="mb-4 block text-xs font-semibold tracking-widest text-mist uppercase">
                Bildstil
              </label>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                {STYLES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setStyle(s.id)}
                    className={clsx(
                      "rounded-xl border p-3.5 text-left transition-all",
                      style === s.id
                        ? "border-violet-400/60 bg-violet-500/15 shadow-lg shadow-violet-500/10"
                        : "border-white/8 bg-white/[0.03] hover:border-white/20",
                    )}
                  >
                    <div className="text-sm font-semibold text-white">{s.label}</div>
                    <div className="mt-1 text-[11px] leading-snug text-mist">{s.hint}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-6 lg:col-span-2">
              <div className="glass rounded-2xl p-6">
                <label className="mb-4 block text-xs font-semibold tracking-widest text-mist uppercase">
                  Erzählstimme (kostenlos via Pollinations)
                </label>
                <div className="flex items-center gap-2">
                  <select
                    value={voice}
                    onChange={(e) => setVoice(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-ink/60 px-4 py-2.5 text-sm text-white focus:border-violet-400/60 focus:outline-none"
                  >
                    {VOICES.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.label}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={previewVoice}
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5 transition-colors hover:bg-white/10"
                    title="Stimme anhören"
                  >
                    {voicePreviewing ? (
                      <Loader2 className="h-4 w-4 animate-spin text-violet-300" />
                    ) : (
                      <Play className="h-4 w-4 text-violet-300" />
                    )}
                  </button>
                </div>
              </div>

              <div className="glass rounded-2xl p-6">
                <div className="mb-2 flex items-center justify-between">
                  <label className="text-xs font-semibold tracking-widest text-mist uppercase">
                    Szenenanzahl
                  </label>
                  <span className="font-display text-lg font-bold text-violet-200">
                    {sceneCount}
                  </span>
                </div>
                <input
                  type="range"
                  min={3}
                  max={8}
                  value={sceneCount}
                  onChange={(e) => setSceneCount(Number(e.target.value))}
                  className="w-full"
                />
                <div className="mt-1 flex justify-between text-[10px] text-mist/60">
                  <span>Kurz & knackig</span>
                  <span>Ausführlich</span>
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 rounded-xl border border-red-400/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">
              <TriangleAlert className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          <button
            onClick={generate}
            disabled={generating}
            className="group flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-violet-500 via-fuchsia-500 to-orange-400 p-[1px] transition-transform hover:scale-[1.005] active:scale-[0.995] disabled:opacity-60"
          >
            <span className="flex w-full items-center justify-center gap-3 rounded-2xl bg-ink/80 px-8 py-5 font-display text-lg font-bold text-white backdrop-blur transition-colors group-hover:bg-ink/60">
              {generating ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Mistral schreibt dein Drehbuch …
                </>
              ) : (
                <>
                  <Wand2 className="h-5 w-5" />
                  Drehbuch generieren
                </>
              )}
            </span>
          </button>
        </motion.div>
      )}

      {/* ------------ SCHRITT 2 ------------ */}
      {step === 2 && (
        <motion.div
          key="step2"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          <div className="glass flex flex-wrap items-center justify-between gap-4 rounded-2xl p-5">
            <div className="min-w-0 flex-1">
              <input
                value={videoTitle}
                onChange={(e) => setVideoTitle(e.target.value)}
                className="w-full bg-transparent font-display text-2xl font-bold text-white focus:outline-none sm:text-3xl"
                placeholder="Filmtitel"
              />
              <div className="mt-1 text-xs text-mist">
                {scenes.length} Szenen · Stimme: {voice} · Stil: {style}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={resetAll}
                className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-semibold transition-colors hover:bg-white/10"
              >
                <X className="h-3.5 w-3.5" /> Neu starten
              </button>
              <button
                onClick={saveProject}
                disabled={saving}
                className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-semibold transition-colors hover:bg-white/10"
              >
                {savedTick ? (
                  <Check className="h-3.5 w-3.5 text-emerald-300" />
                ) : saving ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Save className="h-3.5 w-3.5" />
                )}
                {savedTick ? "Gespeichert" : "Speichern"}
              </button>
              <button
                onClick={() => setStep(3)}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-violet-500/25 transition-transform hover:scale-[1.03]"
              >
                <Clapperboard className="h-4 w-4" />
                Weiter zum Film
              </button>
            </div>
          </div>

          <div className="grid gap-5 md:grid-cols-2">
            {scenes.map((scene, i) => (
              <SceneCard
                key={scene.id}
                scene={scene}
                index={i}
                onChange={(patch) => updateScene(scene.id, patch)}
              />
            ))}
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => setStep(3)}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-violet-500/25 transition-transform hover:scale-[1.03]"
            >
              <Clapperboard className="h-4 w-4" />
              Assets generieren & Film schneiden
            </button>
          </div>
        </motion.div>
      )}

      {/* ------------ SCHRITT 3 ------------ */}
      {step === 3 && (
        <motion.div
          key="step3"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <RenderStage
            scenes={scenes}
            voice={voice}
            videoTitle={videoTitle}
            onBack={() => setStep(2)}
          />
        </motion.div>
      )}
    </div>
  );
}

/* ---------------- Szene-Karte ---------------- */

function SceneCard({
  scene,
  index,
  onChange,
}: {
  scene: StudioScene;
  index: number;
  onChange: (patch: Partial<StudioScene>) => void;
}) {
  const [loaded, setLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    setLoaded(false);
    setImgError(false);
  }, [scene.seed, scene.imagePrompt]);

  return (
    <div className="glass group overflow-hidden rounded-2xl">
      <div className="relative aspect-video bg-ink-3">
        {!imgError ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={proxyImageUrl(scene.imagePrompt, { w: 640, h: 360, seed: scene.seed })}
            alt={scene.title}
            loading="lazy"
            onLoad={() => setLoaded(true)}
            onError={() => setImgError(true)}
            className={clsx(
              "h-full w-full object-cover transition-opacity duration-700",
              loaded ? "opacity-100" : "opacity-0",
            )}
          />
        ) : (
          <div className="flex h-full items-center justify-center text-xs text-red-300">
            Bild fehlgeschlagen — bitte neu generieren
          </div>
        )}
        {!loaded && !imgError && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Loader2 className="h-6 w-6 animate-spin text-violet-300/70" />
          </div>
        )}
        <div className="absolute top-3 left-3 rounded-full bg-black/60 px-3 py-1 font-display text-xs font-bold tracking-wider text-white backdrop-blur">
          SZENE {String(index + 1).padStart(2, "0")}
        </div>
        <button
          onClick={() => onChange({ seed: Math.floor(Math.random() * 999_999) + 1 })}
          className="absolute top-3 right-3 flex items-center gap-1.5 rounded-full bg-black/60 px-3 py-1.5 text-[11px] font-semibold text-white opacity-0 backdrop-blur transition-opacity group-hover:opacity-100"
          title="Bild neu würfeln"
        >
          <Dices className="h-3.5 w-3.5" /> Neu
        </button>
      </div>

      <div className="space-y-3 p-5">
        <input
          value={scene.title}
          onChange={(e) => onChange({ title: e.target.value })}
          className="w-full bg-transparent font-display text-lg font-bold text-white focus:outline-none"
          placeholder="Szenentitel"
        />
        <div>
          <div className="mb-1.5 flex items-center justify-between text-[10px] font-semibold tracking-widest text-mist/70 uppercase">
            <span>Erzähltext</span>
            <span className={scene.narration.length > 360 ? "text-amber-300" : ""}>
              {scene.narration.length}/380
            </span>
          </div>
          <textarea
            value={scene.narration}
            onChange={(e) => onChange({ narration: e.target.value.slice(0, 380) })}
            rows={3}
            className="w-full resize-none rounded-lg border border-white/8 bg-ink/50 p-3 text-sm leading-relaxed text-bright/90 focus:border-violet-400/50 focus:outline-none"
          />
        </div>
        <button
          onClick={() => setShowPrompt((v) => !v)}
          className="flex items-center gap-1.5 text-[11px] font-semibold text-mist transition-colors hover:text-violet-200"
        >
          <RefreshCw className="h-3 w-3" />
          Bild-Prompt {showPrompt ? "ausblenden" : "bearbeiten"}
        </button>
        {showPrompt && (
          <textarea
            value={scene.imagePrompt}
            onChange={(e) => onChange({ imagePrompt: e.target.value.slice(0, 480) })}
            rows={3}
            className="w-full resize-none rounded-lg border border-white/8 bg-ink/50 p-3 font-mono text-xs leading-relaxed text-bright/80 focus:border-violet-400/50 focus:outline-none"
          />
        )}
      </div>
    </div>
  );
}
