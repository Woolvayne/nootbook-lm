"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  AudioLines,
  Check,
  CircleAlert,
  Download,
  Film,
  Image as ImageIcon,
  Loader2,
  Play,
  RotateCcw,
  Square,
  Wand2,
} from "lucide-react";
import clsx from "clsx";
import type { StudioScene } from "@/lib/types";
import { proxyImageUrl, proxyTtsUrl } from "@/lib/pollinations";
import { ExplainerRenderer, type PreparedScene, VIDEO_SIZE } from "@/lib/video/renderer";

type AssetStatus = "idle" | "loading" | "done" | "error";

interface AssetEntry {
  fp: string;
  image: ImageBitmap | null;
  audio: AudioBuffer | null;
  imageStatus: AssetStatus;
  audioStatus: AssetStatus;
}

type Phase = "idle" | "loading" | "ready" | "previewing" | "recording" | "done";

function fingerprint(s: StudioScene) {
  return `${s.id}|${s.seed}|${s.imagePrompt.length}|${s.narration}|${s.imagePrompt.slice(0, 24)}`;
}

function slug(s: string) {
  return (
    s
      .toLowerCase()
      .replace(/[äÄ]/g, "ae")
      .replace(/[öÖ]/g, "oe")
      .replace(/[üÜ]/g, "ue")
      .replace(/ß/g, "ss")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "narrato-video"
  );
}

export default function RenderStage({
  scenes,
  voice,
  videoTitle,
  onBack,
}: {
  scenes: StudioScene[];
  voice: string;
  videoTitle: string;
  onBack: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<ExplainerRenderer | null>(null);
  const videoUrlRef = useRef<string | null>(null);

  const [assets, setAssets] = useState<Record<string, AssetEntry>>({});
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);
  const [currentScene, setCurrentScene] = useState(0);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoSize, setVideoSize] = useState(0);
  const [assetError, setAssetError] = useState<string | null>(null);

  // Assets invalidieren, wenn sich Szenen ändern
  useEffect(() => {
    setAssets((prev) => {
      const next: Record<string, AssetEntry> = {};
      let changed = false;
      for (const s of scenes) {
        const fp = fingerprint(s);
        const old = prev[s.id];
        if (old && old.fp === fp) {
          next[s.id] = old;
        } else {
          changed = true;
          next[s.id] = {
            fp,
            image: null,
            audio: null,
            imageStatus: "idle",
            audioStatus: "idle",
          };
        }
      }
      if (changed) {
        setPhase((p) => (p === "done" || p === "ready" ? "idle" : p));
        if (videoUrlRef.current) {
          URL.revokeObjectURL(videoUrlRef.current);
          videoUrlRef.current = null;
          setVideoUrl(null);
        }
      }
      return next;
    });
  }, [scenes]);

  useEffect(() => {
    return () => {
      rendererRef.current?.stop();
      if (videoUrlRef.current) URL.revokeObjectURL(videoUrlRef.current);
    };
  }, []);

  const getRenderer = () => {
    if (!rendererRef.current && canvasRef.current) {
      rendererRef.current = new ExplainerRenderer(canvasRef.current);
    }
    return rendererRef.current;
  };

  const setAsset = (id: string, patch: Partial<AssetEntry>) => {
    setAssets((prev) => ({
      ...prev,
      [id]: { ...prev[id], ...patch },
    }));
  };

  const loadSceneAssets = async (scene: StudioScene, renderer: ExplainerRenderer) => {
    setAsset(scene.id, { imageStatus: "loading", audioStatus: "loading" });

    // Bild
    try {
      const res = await fetch(
        proxyImageUrl(scene.imagePrompt, { w: VIDEO_SIZE.width, h: VIDEO_SIZE.height, seed: scene.seed }),
      );
      if (!res.ok) throw new Error("image");
      const blob = await res.blob();
      const bmp = await createImageBitmap(blob);
      setAsset(scene.id, { image: bmp, imageStatus: "done" });
    } catch {
      setAsset(scene.id, { imageStatus: "error" });
    }

    // Audio
    try {
      const res = await fetch(proxyTtsUrl(scene.narration, voice));
      if (!res.ok) throw new Error("audio");
      const buf = await res.arrayBuffer();
      const audio = await renderer.audioCtx.decodeAudioData(buf);
      setAsset(scene.id, { audio, audioStatus: "done" });
    } catch {
      setAsset(scene.id, { audioStatus: "error" });
    }
  };

  const generateAssets = async () => {
    const renderer = getRenderer();
    if (!renderer) return;
    setAssetError(null);
    setPhase("loading");
    setProgress(0);

    const pending = scenes.filter((s) => {
      const a = assets[s.id];
      return !a || a.imageStatus !== "done" || a.audioStatus !== "done";
    });

    let done = 0;
    const total = pending.length;
    if (total === 0) {
      setPhase("ready");
      return;
    }
    const queue = [...pending];
    await Promise.all(
      Array.from({ length: 3 }, async () => {
        while (queue.length > 0) {
          const s = queue.shift();
          if (!s) break;
          await loadSceneAssets(s, renderer);
          done += 1;
          setProgress(done / total);
        }
      }),
    );

    // Erfolg prüfen
    setAssets((latest) => {
      const failed = scenes.filter(
        (s) => latest[s.id]?.imageStatus === "error" || latest[s.id]?.audioStatus === "error",
      );
      if (failed.length > 0) {
        setAssetError(
          `${failed.length} Szene(n) konnten nicht generiert werden. Klicke auf „Erneut versuchen“ — Pollinations braucht manchmal einen zweiten Anlauf.`,
        );
        setPhase("idle");
      } else {
        setPhase("ready");
      }
      return latest;
    });
  };

  const prepared: PreparedScene[] | null = useMemo(() => {
    for (const s of scenes) {
      const a = assets[s.id];
      if (!a?.image || !a?.audio) return null;
    }
    return scenes.map((s) => ({
      title: s.title,
      narration: s.narration,
      image: assets[s.id].image as ImageBitmap,
      audio: assets[s.id].audio as AudioBuffer,
    }));
  }, [assets, scenes]);

  const totalSeconds = useMemo(() => {
    if (!prepared) return 0;
    return prepared.reduce((acc, s) => acc + s.audio.duration + 0.45, 0);
  }, [prepared]);

  const run = async (record: boolean) => {
    const renderer = getRenderer();
    if (!renderer || !prepared) return;
    setProgress(0);
    setPhase(record ? "recording" : "previewing");
    try {
      const blob = await renderer.run(prepared, {
        record,
        onProgress: setProgress,
        onScene: (i) => setCurrentScene(i),
      });
      if (record && blob && blob.size > 0) {
        if (videoUrlRef.current) URL.revokeObjectURL(videoUrlRef.current);
        const url = URL.createObjectURL(blob);
        videoUrlRef.current = url;
        setVideoUrl(url);
        setVideoSize(blob.size);
        setPhase("done");
      } else {
        setPhase("ready");
      }
    } catch {
      setPhase("ready");
    }
  };

  const stop = () => {
    rendererRef.current?.stop();
    setPhase((p) => (p === "previewing" ? "ready" : p));
  };

  const busy = phase === "loading" || phase === "previewing" || phase === "recording";
  const allDoneCount = scenes.filter(
    (s) => assets[s.id]?.imageStatus === "done" && assets[s.id]?.audioStatus === "done",
  ).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          disabled={busy}
          className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-semibold transition-colors hover:bg-white/10 disabled:opacity-40"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Zurück zum Drehbuch
        </button>
        <div className="text-xs text-mist">
          {allDoneCount}/{scenes.length} Szenen bereit
        </div>
      </div>

      {/* Canvas-Bühne */}
      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black shadow-2xl shadow-violet-500/10">
        <canvas
          ref={canvasRef}
          width={VIDEO_SIZE.width}
          height={VIDEO_SIZE.height}
          className="aspect-video w-full"
        />
        {(phase === "idle" || phase === "loading") && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 bg-ink/85 backdrop-blur-sm">
            {phase === "idle" ? (
              <>
                <div className="ring-conic animate-pulse-glow flex h-16 w-16 items-center justify-center rounded-2xl">
                  <Wand2 className="h-7 w-7 text-white" />
                </div>
                <div className="text-center">
                  <div className="font-display text-xl font-bold">Bilder & Stimme generieren</div>
                  <p className="mx-auto mt-2 max-w-sm text-sm text-mist">
                    Für jede Szene wird jetzt ein Bild gemalt und der Erzähltext
                    vertont — komplett kostenlos via Pollinations.
                  </p>
                </div>
                <button
                  onClick={generateAssets}
                  className="flex items-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 px-8 py-3.5 text-sm font-bold text-white shadow-xl shadow-violet-500/30 transition-transform hover:scale-[1.04] active:scale-95"
                >
                  <Wand2 className="h-4 w-4" />
                  {assetError ? "Erneut versuchen" : "Assets generieren"}
                </button>
                {assetError && (
                  <p className="mx-auto max-w-md px-4 text-center text-xs leading-relaxed text-amber-200">
                    {assetError}
                  </p>
                )}
              </>
            ) : (
              <>
                <Loader2 className="h-10 w-10 animate-spin text-violet-300" />
                <div className="text-center">
                  <div className="font-display text-lg font-bold">
                    Pollinations arbeitet … {Math.round(progress * 100)} %
                  </div>
                  <p className="mt-1 text-xs text-mist">
                    Bilder werden gemalt, Text wird eingesprochen. Das kann 1–3 Minuten dauern.
                  </p>
                </div>
                <div className="h-1.5 w-64 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-violet-500 via-fuchsia-500 to-orange-400 transition-all duration-500"
                    style={{ width: `${progress * 100}%` }}
                  />
                </div>
              </>
            )}
          </div>
        )}

        {(phase === "previewing" || phase === "recording") && (
          <div className="absolute right-4 bottom-4 flex items-center gap-3">
            {phase === "recording" && (
              <span className="flex items-center gap-2 rounded-full bg-red-500/20 px-3 py-1.5 text-xs font-bold text-red-200 backdrop-blur">
                <span className="h-2 w-2 animate-pulse rounded-full bg-red-400" />
                REC · Szene {currentScene + 1}/{scenes.length}
              </span>
            )}
            <button
              onClick={stop}
              className="flex items-center gap-1.5 rounded-full bg-black/60 px-4 py-2 text-xs font-bold text-white backdrop-blur transition-colors hover:bg-black/80"
            >
              <Square className="h-3 w-3" /> Stopp
            </button>
          </div>
        )}
      </div>

      {/* Szenen-Status */}
      <div className="flex flex-wrap gap-2">
        {scenes.map((s, i) => {
          const a = assets[s.id];
          const status: AssetStatus =
            a?.imageStatus === "done" && a?.audioStatus === "done"
              ? "done"
              : a?.imageStatus === "error" || a?.audioStatus === "error"
                ? "error"
                : a?.imageStatus === "loading"
                  ? "loading"
                  : "idle";
          return (
            <div
              key={s.id}
              className={clsx(
                "glass flex items-center gap-2 rounded-full px-3.5 py-2 text-xs",
                status === "error" && "border-red-400/40",
              )}
            >
              <span className="font-display font-bold text-mist">{String(i + 1).padStart(2, "0")}</span>
              <span className="max-w-28 truncate text-white">{s.title}</span>
              {status === "done" ? (
                <Check className="h-3.5 w-3.5 text-emerald-300" />
              ) : status === "loading" ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin text-violet-300" />
              ) : status === "error" ? (
                <CircleAlert className="h-3.5 w-3.5 text-red-300" />
              ) : (
                <span className="flex gap-1">
                  <ImageIcon className="h-3.5 w-3.5 text-mist/40" />
                  <AudioLines className="h-3.5 w-3.5 text-mist/40" />
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* Aktionen */}
      <div className="glass flex flex-wrap items-center gap-3 rounded-2xl p-5">
        <button
          onClick={() => run(false)}
          disabled={!prepared || busy}
          className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-5 py-3 text-sm font-semibold transition-colors hover:bg-white/10 disabled:opacity-40"
        >
          <Play className="h-4 w-4 text-violet-300" />
          Vorschau abspielen
        </button>
        <button
          onClick={() => run(true)}
          disabled={!prepared || busy}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-violet-500/25 transition-transform hover:scale-[1.03] disabled:opacity-40 disabled:hover:scale-100"
        >
          {phase === "recording" ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Film className="h-4 w-4" />
          )}
          {phase === "recording"
            ? `Schneide … ${Math.round(progress * 100)} %`
            : "Film rendern"}
        </button>
        {prepared && (
          <span className="text-xs text-mist">
            Filmlänge: ca. {Math.floor(totalSeconds / 60)}:{String(Math.round(totalSeconds % 60)).padStart(2, "0")} Min.
            · 1280×720 · WebM
          </span>
        )}
        {!prepared && phase !== "loading" && (
          <span className="text-xs text-mist">
            Zuerst Assets generieren, dann hier rendern.
          </span>
        )}
      </div>

      {/* Ergebnis */}
      {videoUrl && (
        <div className="glass space-y-4 rounded-2xl p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/15">
                <Check className="h-5 w-5 text-emerald-300" />
              </span>
              <div>
                <div className="font-display font-bold">Dein Erklärfilm ist fertig!</div>
                <div className="text-xs text-mist">
                  {(videoSize / (1024 * 1024)).toFixed(1)} MB · WebM (VP9) · {videoTitle}
                </div>
              </div>
            </div>
            <a
              href={videoUrl}
              download={`${slug(videoTitle)}.webm`}
              className="flex items-center gap-2 rounded-xl bg-white px-6 py-3 text-sm font-bold text-ink shadow-xl transition-transform hover:scale-[1.04] active:scale-95"
            >
              <Download className="h-4 w-4" />
              Video herunterladen
            </a>
          </div>
          {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
          <video
            src={videoUrl}
            controls
            className="w-full rounded-xl border border-white/10"
          />
          <div className="flex flex-wrap items-center gap-3 text-xs text-mist">
            <button
              onClick={() => run(true)}
              disabled={busy}
              className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-2 font-semibold transition-colors hover:bg-white/10 disabled:opacity-40"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Neu rendern
            </button>
            <span>
              Tipp: WebM läuft in jedem modernen Browser &amp; auf YouTube. Für MP4 einfach mit
              einem kostenlosen Konverter (z. B. CloudConvert) umwandeln.
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
