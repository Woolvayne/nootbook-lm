"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Bot,
  Check,
  Copy,
  KeyRound,
  Loader2,
  Plug,
  Plus,
  Server,
  Sparkles,
  Terminal,
  Trash2,
  TriangleAlert,
} from "lucide-react";
import clsx from "clsx";

interface ApiKeyRow {
  id: string;
  name: string;
  key: string;
  createdAt: string;
}

function CopyBtn({ text, label }: { text: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setDone(true);
          setTimeout(() => setDone(false), 1800);
        } catch {
          /* ignore */
        }
      }}
      className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-mist transition-colors hover:bg-white/10 hover:text-white"
    >
      {done ? (
        <Check className="h-3 w-3 text-emerald-300" />
      ) : (
        <Copy className="h-3 w-3" />
      )}
      {done ? "Kopiert" : (label ?? "Kopieren")}
    </button>
  );
}

function CodeBlock({ title, code }: { title: string; code: string }) {
  return (
    <div className="glass overflow-hidden rounded-2xl">
      <div className="flex items-center justify-between border-b border-white/5 px-5 py-3">
        <span className="flex items-center gap-2 text-xs font-semibold text-mist">
          <Terminal className="h-3.5 w-3.5" />
          {title}
        </span>
        <CopyBtn text={code} />
      </div>
      <pre className="overflow-x-auto p-5 text-[12.5px] leading-relaxed text-violet-200/90">
        <code>{code}</code>
      </pre>
    </div>
  );
}

export default function ConnectClient() {
  const [keys, setKeys] = useState<ApiKeyRow[]>([]);
  const [newName, setNewName] = useState("");
  const [creating, setCreating] = useState(false);
  const [origin, setOrigin] = useState("https://deine-domain.tld");

  const [serverKey, setServerKey] = useState("");
  const [serverStatus, setServerStatus] = useState<{
    loading: boolean;
    set: boolean;
    masked: string | null;
    saving: boolean;
    msg: string | null;
  }>({ loading: true, set: false, masked: null, saving: false, msg: null });

  useEffect(() => {
    setOrigin(window.location.origin);
    void loadKeys();
    void loadSettings();
  }, []);

  const loadKeys = useCallback(async () => {
    try {
      const res = await fetch("/api/keys");
      const data = (await res.json()) as { keys?: ApiKeyRow[] };
      setKeys(data.keys ?? []);
    } catch {
      /* ignore */
    }
  }, []);

  const loadSettings = useCallback(async () => {
    try {
      const res = await fetch("/api/settings");
      const data = (await res.json()) as { serverKeySet: boolean; masked: string | null };
      setServerStatus((s) => ({ ...s, loading: false, set: data.serverKeySet, masked: data.masked }));
    } catch {
      setServerStatus((s) => ({ ...s, loading: false }));
    }
  }, []);

  const createKey = async () => {
    setCreating(true);
    try {
      await fetch("/api/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName || "KI-Assistent" }),
      });
      setNewName("");
      await loadKeys();
    } finally {
      setCreating(false);
    }
  };

  const deleteKey = async (id: string) => {
    await fetch(`/api/keys?id=${id}`, { method: "DELETE" });
    await loadKeys();
  };

  const saveServerKey = async () => {
    setServerStatus((s) => ({ ...s, saving: true, msg: null }));
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mistralKey: serverKey }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Fehler");
      setServerKey("");
      setServerStatus((s) => ({ ...s, saving: false, msg: "Server-Schlüssel gespeichert." }));
      await loadSettings();
    } catch (err) {
      setServerStatus((s) => ({
        ...s,
        saving: false,
        msg: err instanceof Error ? err.message : "Fehler",
      }));
    }
  };

  const removeServerKey = async () => {
    await fetch("/api/settings", { method: "DELETE" });
    await loadSettings();
  };

  const curlExample = useMemo(
    () => `curl -X POST ${origin}/api/v1/generate \\
  -H "x-api-key: ${keys[0]?.key ?? "nrto_DEIN_KEY"}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "topic": "Warum leuchten Glühwürmchen?",
    "style": "cinematic",
    "voice": "onyx",
    "sceneCount": 5
  }'`,
    [origin, keys],
  );

  const openApi = useMemo(
    () =>
      JSON.stringify(
        {
          openapi: "3.1.0",
          info: {
            title: "Narrato — KI-Erklärvideo API",
            version: "1.0.0",
            description:
              "Erzeugt komplette Erklärvideo-Projekte (Drehbuch, Bilder, Vertonung) zu einem beliebigen Thema.",
          },
          servers: [{ url: origin }],
          paths: {
            "/api/v1/generate": {
              post: {
                operationId: "generateExplainerVideo",
                summary: "Erklärvideo-Projekt zu einem Thema erzeugen",
                security: [{ ApiKeyHeader: [] }],
                requestBody: {
                  required: true,
                  content: {
                    "application/json": {
                      schema: {
                        type: "object",
                        required: ["topic"],
                        properties: {
                          topic: { type: "string", description: "Das Thema des Erklärvideos" },
                          style: {
                            type: "string",
                            enum: ["cinematic", "flat", "watercolor", "render3d", "photo", "anime"],
                            default: "cinematic",
                          },
                          voice: {
                            type: "string",
                            enum: ["nova", "shimmer", "alloy", "echo", "onyx", "fable"],
                            default: "nova",
                          },
                          sceneCount: { type: "integer", minimum: 3, maximum: 8, default: 5 },
                        },
                      },
                    },
                  },
                },
                responses: { "200": { description: "Projekt mit Szenen, Bild- und Audio-URLs" } },
              },
            },
          },
          components: {
            securitySchemes: {
              ApiKeyHeader: { type: "apiKey", in: "header", name: "x-api-key" },
            },
          },
        },
        null,
        2,
      ),
    [origin],
  );

  const assistantPrompt = useMemo(
    () => `Wenn der Nutzer ein Erklärvideo zu einem Thema möchte, rufe die Narrato-API auf:
POST ${origin}/api/v1/generate
Header: x-api-key: ${keys[0]?.key ?? "nrto_DEIN_KEY"}, Content-Type: application/json
Body: {"topic": "<Thema>", "style": "cinematic", "voice": "nova", "sceneCount": 5}

Die Antwort enthält den Filmtitel, alle Szenen mit Erzähltext sowie direkte
URLs zu den generierten Bildern und Audiodateien. Verweise den Nutzer
anschließend auf studioUrl, um das Video zu rendern und herunterzuladen.`,
    [origin, keys],
  );

  return (
    <div className="mx-auto max-w-5xl px-5 pt-32 pb-24 sm:px-8">
      {/* Kopf */}
      <div className="mb-12 text-center">
        <div className="glass mx-auto mb-6 flex w-fit items-center gap-2 rounded-full px-4 py-2 text-xs font-medium text-mist">
          <Plug className="h-3.5 w-3.5 text-fuchsia-300" />
          INTEGRATIONEN
        </div>
        <h1 className="font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl">
          Verbinde Narrato mit <span className="text-gradient">deinen KI-Assistenten</span>
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-mist">
          Custom GPTs, Claude-Projekte, LangChain-Agenten oder eigene Tools können
          per REST-API komplette Erklärvideos auslösen — inklusive Drehbuch,
          Bildern und Vertonung.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* API-Keys */}
        <div className="glass rounded-2xl p-6">
          <div className="mb-5 flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-500/15">
              <KeyRound className="h-5 w-5 text-violet-300" />
            </span>
            <div>
              <h2 className="font-display text-lg font-bold">1 · API-Keys</h2>
              <p className="text-xs text-mist">Schlüssel für deine Assistenten anlegen</p>
            </div>
          </div>
          <div className="flex gap-2">
            <input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Name, z. B. „Mein Custom GPT“"
              className="min-w-0 flex-1 rounded-xl border border-white/10 bg-ink/60 px-4 py-2.5 text-sm text-white placeholder:text-mist/40 focus:border-violet-400/60 focus:outline-none"
            />
            <button
              onClick={createKey}
              disabled={creating}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 px-4 py-2.5 text-xs font-bold text-white transition-transform hover:scale-[1.04] disabled:opacity-50"
            >
              {creating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
              Erstellen
            </button>
          </div>
          <div className="mt-4 space-y-2">
            {keys.length === 0 && (
              <p className="rounded-xl border border-dashed border-white/10 p-4 text-center text-xs text-mist">
                Noch keine Keys — erstelle deinen ersten.
              </p>
            )}
            {keys.map((k) => (
              <div
                key={k.id}
                className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-4 py-3"
              >
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold">{k.name}</div>
                  <div className="truncate font-mono text-[11px] text-mist">{k.key}</div>
                </div>
                <CopyBtn text={k.key} label="Key" />
                <button
                  onClick={() => deleteKey(k.id)}
                  className="rounded-lg p-2 text-mist/50 transition-colors hover:bg-red-500/10 hover:text-red-300"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Server Mistral-Key */}
        <div className="glass rounded-2xl p-6">
          <div className="mb-5 flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-fuchsia-500/15">
              <Server className="h-5 w-5 text-fuchsia-300" />
            </span>
            <div>
              <h2 className="font-display text-lg font-bold">2 · Mistral-Schlüssel fürs Backend</h2>
              <p className="text-xs text-mist">Damit Assistenten ohne eigenen Key generieren können</p>
            </div>
          </div>
          <div
            className={clsx(
              "mb-4 flex items-center gap-2 rounded-xl border px-4 py-3 text-sm",
              serverStatus.set
                ? "border-emerald-400/30 bg-emerald-500/10 text-emerald-200"
                : "border-amber-400/30 bg-amber-500/10 text-amber-200",
            )}
          >
            {serverStatus.loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : serverStatus.set ? (
              <>
                <Check className="h-4 w-4" /> Hinterlegt: <span className="font-mono">{serverStatus.masked}</span>
              </>
            ) : (
              <>
                <TriangleAlert className="h-4 w-4" /> Nicht hinterlegt — Assistenten brauchen sonst ihren eigenen
                Schlüssel (Header <code className="font-mono">x-mistral-key</code>).
              </>
            )}
          </div>
          <div className="flex gap-2">
            <input
              type="password"
              value={serverKey}
              onChange={(e) => setServerKey(e.target.value)}
              placeholder="Mistral API-Schlüssel einfügen"
              className="min-w-0 flex-1 rounded-xl border border-white/10 bg-ink/60 px-4 py-2.5 font-mono text-sm text-white placeholder:text-mist/40 focus:border-violet-400/60 focus:outline-none"
            />
            <button
              onClick={saveServerKey}
              disabled={serverStatus.saving || serverKey.trim().length < 10}
              className="rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-bold transition-colors hover:bg-white/10 disabled:opacity-40"
            >
              {serverStatus.saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Speichern"}
            </button>
            {serverStatus.set && (
              <button
                onClick={removeServerKey}
                className="rounded-xl border border-red-400/30 bg-red-500/10 px-4 py-2.5 text-xs font-bold text-red-200 transition-colors hover:bg-red-500/20"
              >
                Entfernen
              </button>
            )}
          </div>
          {serverStatus.msg && <p className="mt-3 text-xs text-mist">{serverStatus.msg}</p>}
          <p className="mt-4 text-[11px] leading-relaxed text-mist/70">
            Hinweis: Der Schlüssel liegt in der lokalen Datenbank dieser Instanz und wird
            ausschließlich für Mistral-Requests über dieses Backend verwendet.
          </p>
        </div>
      </div>

      {/* Docs */}
      <div id="docs" className="mt-16 scroll-mt-24">
        <div className="mb-8 flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-orange-500/15">
            <Bot className="h-5 w-5 text-orange-300" />
          </span>
          <div>
            <h2 className="font-display text-2xl font-bold">3 · Dokumentation</h2>
            <p className="text-xs text-mist">Alles, was dein Assistent wissen muss</p>
          </div>
        </div>

        <div className="grid gap-6">
          {/* Endpoint-Tabelle */}
          <div className="glass overflow-hidden rounded-2xl">
            <div className="border-b border-white/5 px-5 py-3.5 text-xs font-semibold text-mist">
              ENDPUNKTE
            </div>
            <div className="divide-y divide-white/5 text-sm">
              <div className="flex flex-wrap items-center gap-3 px-5 py-4">
                <span className="rounded-md bg-emerald-500/15 px-2.5 py-1 font-mono text-xs font-bold text-emerald-300">POST</span>
                <code className="font-mono text-violet-200">/api/v1/generate</code>
                <span className="text-xs text-mist">Erzeugt ein komplettes Erklärvideo-Projekt</span>
              </div>
              <div className="flex flex-wrap items-center gap-3 px-5 py-4">
                <span className="rounded-md bg-sky-500/15 px-2.5 py-1 font-mono text-xs font-bold text-sky-300">GET</span>
                <code className="font-mono text-violet-200">/api/v1/projects</code>
                <span className="text-xs text-mist">Listet bisherige Projekte</span>
              </div>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div className="glass rounded-2xl p-5">
              <div className="mb-3 text-xs font-semibold tracking-widest text-mist uppercase">Parameter</div>
              <div className="space-y-3 text-sm">
                {[
                  ["topic", "string · Pflicht", "Thema des Videos"],
                  ["style", "cinematic · flat · watercolor · render3d · photo · anime", "Bildstil (Standard: cinematic)"],
                  ["voice", "nova · shimmer · alloy · echo · onyx · fable", "Sprecherstimme (Standard: nova)"],
                  ["sceneCount", "3–8", "Anzahl der Szenen (Standard: 5)"],
                ].map(([name, type, desc]) => (
                  <div key={name} className="rounded-xl border border-white/5 bg-white/[0.02] p-3.5">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <code className="font-mono font-bold text-fuchsia-200">{name}</code>
                      <span className="font-mono text-[10px] text-mist/70">{type}</span>
                    </div>
                    <p className="mt-1 text-xs text-mist">{desc}</p>
                  </div>
                ))}
              </div>
            </div>
            <CodeBlock title="Beispiel: cURL" code={curlExample} />
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <CodeBlock title="OpenAPI-Schema (für GPT Actions)" code={openApi} />
            <CodeBlock title="Fertige Anweisung für deinen Assistenten" code={assistantPrompt} />
          </div>

          {/* Anleitung */}
          <div className="glass rounded-2xl p-6">
            <div className="mb-5 flex items-center gap-2 text-xs font-semibold tracking-widest text-mist uppercase">
              <Sparkles className="h-3.5 w-3.5 text-violet-300" />
              So geht's — z. B. mit einem Custom GPT
            </div>
            <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                ["Key erstellen", "Oben einen API-Key anlegen und kopieren."],
                ["Schema kopieren", "Das OpenAPI-Schema oben in die Zwischenablage nehmen."],
                ["GPT konfigurieren", "In ChatGPT: „GPT erstellen“ → Configure → Actions → Schema einfügen → Authentication: API Key (Header „x-api-key“)."],
                ["Loslegen", "Sage deinem GPT: „Erstelle ein Erklärvideo über …“ — fertig."],
              ].map(([t, d], i) => (
                <li key={t} className="rounded-xl border border-white/5 bg-white/[0.03] p-4">
                  <div className="ring-conic mb-3 flex h-7 w-7 items-center justify-center rounded-full font-display text-xs font-bold text-white">
                    {i + 1}
                  </div>
                  <div className="text-sm font-semibold">{t}</div>
                  <p className="mt-1.5 text-xs leading-relaxed text-mist">{d}</p>
                </li>
              ))}
            </ol>
            <p className="mt-5 text-xs leading-relaxed text-mist/70">
              Für Claude &amp; andere Assistenten: einfach die „Fertige Anweisung“ in das
              System-Prompt-/Projekt-Wissen kopieren. Der Assistent ruft den Endpunkt dann
              über sein HTTP-Tool auf.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
