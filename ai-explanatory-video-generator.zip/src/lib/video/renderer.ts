"use client";

export interface PreparedScene {
  title: string;
  narration: string;
  image: ImageBitmap;
  audio: AudioBuffer;
}

export interface RenderCallbacks {
  onProgress?: (fraction: number) => void;
  onScene?: (index: number, total: number) => void;
}

const W = 1280;
const H = 720;

function easeInOut(t: number): number {
  return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
}

export class ExplainerRenderer {
  private ctx: CanvasRenderingContext2D;
  readonly audioCtx: AudioContext;
  private fontFamily: string;
  private raf = 0;
  private stopped = false;
  private activeSources: AudioBufferSourceNode[] = [];

  constructor(private canvas: HTMLCanvasElement) {
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("Canvas 2D nicht verfügbar.");
    this.ctx = ctx;
    this.audioCtx = new AudioContext();
    this.fontFamily = "'Space Grotesk', system-ui, sans-serif";
    if (typeof document !== "undefined") {
      const bodyFont = getComputedStyle(document.body).fontFamily;
      if (bodyFont) this.fontFamily = bodyFont;
    }
  }

  async ensureFonts(): Promise<void> {
    try {
      await document.fonts.ready;
    } catch {
      /* ignore */
    }
  }

  stop(): void {
    this.stopped = true;
    cancelAnimationFrame(this.raf);
    for (const s of this.activeSources) {
      try {
        s.stop();
      } catch {
        /* ignore */
      }
    }
    this.activeSources = [];
  }

  async run(
    scenes: PreparedScene[],
    opts: { record: boolean } & RenderCallbacks,
  ): Promise<Blob | null> {
    this.stopped = false;
    if (this.audioCtx.state === "suspended") await this.audioCtx.resume();
    await this.ensureFonts();

    const dest = this.audioCtx.createMediaStreamDestination();
    let recorder: MediaRecorder | null = null;
    const chunks: Blob[] = [];

    if (opts.record) {
      const stream = this.canvas.captureStream(30);
      const mixed = new MediaStream([
        ...stream.getVideoTracks(),
        ...dest.stream.getAudioTracks(),
      ]);
      const mime = [
        "video/webm;codecs=vp9,opus",
        "video/webm;codecs=vp8,opus",
        "video/webm",
      ].find((m) => MediaRecorder.isTypeSupported(m));
      recorder = new MediaRecorder(
        mixed,
        mime
          ? { mimeType: mime, videoBitsPerSecond: 9_000_000 }
          : { videoBitsPerSecond: 9_000_000 },
      );
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      recorder.start(1000);
    }

    const stopRecorder = () =>
      new Promise<void>((res) => {
        if (!recorder || recorder.state === "inactive") return res();
        recorder.onstop = () => res();
        try {
          recorder.stop();
        } catch {
          res();
        }
      });

    // kurzer schwarzer Vorlauf, damit der Recorder startklar ist
    this.drawBlack();
    if (opts.record) await this.sleep(400);

    try {
      for (let i = 0; i < scenes.length; i++) {
        if (this.stopped) break;
        opts.onScene?.(i, scenes.length);
        await this.playScene(scenes[i], i, scenes.length, dest, opts.record, (p) =>
          opts.onProgress?.((i + p) / scenes.length),
        );
      }
    } finally {
      if (opts.record) {
        this.drawBlack();
        await this.sleep(250);
      }
      await stopRecorder();
    }
    opts.onProgress?.(1);
    return opts.record
      ? new Blob(chunks, { type: recorder?.mimeType || "video/webm" })
      : null;
  }

  private sleep(ms: number) {
    return new Promise((r) => setTimeout(r, ms));
  }

  private drawBlack() {
    this.ctx.fillStyle = "#000";
    this.ctx.fillRect(0, 0, W, H);
  }

  private playScene(
    scene: PreparedScene,
    index: number,
    total: number,
    dest: MediaStreamAudioDestinationNode,
    record: boolean,
    onP: (p: number) => void,
  ): Promise<void> {
    return new Promise((resolve) => {
      const src = this.audioCtx.createBufferSource();
      src.buffer = scene.audio;
      src.connect(dest);
      if (!record) src.connect(this.audioCtx.destination);
      this.activeSources.push(src);

      const dur = scene.audio.duration;
      const pad = 0.45; // Atempause nach jeder Szene
      const t0 = this.audioCtx.currentTime + 0.08;
      src.start(t0);

      const draw = () => {
        if (this.stopped) {
          resolve();
          return;
        }
        const t = this.audioCtx.currentTime - t0;
        const span = dur + pad;
        const p = Math.min(Math.max(t / span, 0), 1);
        this.drawFrame(scene, p, index, total);
        onP(p);
        if (t < span) {
          this.raf = requestAnimationFrame(draw);
        } else {
          this.activeSources = this.activeSources.filter((s) => s !== src);
          resolve();
        }
      };
      this.raf = requestAnimationFrame(draw);
    });
  }

  private drawFrame(scene: PreparedScene, p: number, index: number, total: number) {
    const ctx = this.ctx;
    const img = scene.image;

    // --- Ken Burns ---
    const e = easeInOut(p);
    const scale = 1.06 + 0.14 * e;
    const dir = index % 2 === 0 ? 1 : -1;
    const base = Math.max(W / img.width, H / img.height) * scale;
    const dw = img.width * base;
    const dh = img.height * base;
    const dx = (W - dw) / 2 + dir * (e - 0.5) * W * 0.03;
    const dy = (H - dh) / 2 + (dir * (0.5 - e) * H * 0.012);

    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    ctx.drawImage(img, dx, dy, dw, dh);

    // --- Licht / Vignetten ---
    let g = ctx.createLinearGradient(0, H * 0.35, 0, H);
    g.addColorStop(0, "rgba(2,2,8,0)");
    g.addColorStop(1, "rgba(2,2,8,0.82)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    g = ctx.createLinearGradient(0, 0, 0, H * 0.22);
    g.addColorStop(0, "rgba(2,2,8,0.55)");
    g.addColorStop(1, "rgba(2,2,8,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H * 0.22);

    // --- Branding ---
    ctx.textBaseline = "alphabetic";
    ctx.textAlign = "left";
    ctx.font = `600 21px ${this.fontFamily}`;
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fillText("NARRATO", 52, 62);
    ctx.fillStyle = "rgba(167,139,250,0.95)";
    ctx.beginPath();
    this.roundRectPath(52, 74, 52, 3, 2);
    ctx.fill();

    ctx.textAlign = "right";
    ctx.font = `500 20px ${this.fontFamily}`;
    ctx.fillStyle = "rgba(255,255,255,0.65)";
    ctx.fillText(
      `${String(index + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}`,
      W - 52,
      62,
    );
    ctx.textAlign = "left";

    // --- Titel & Untertitel (weich ein-/ausblenden) ---
    const fadeIn = Math.min(1, p / 0.07);
    const fadeOut = Math.min(1, (1 - p) / 0.1);
    const alpha = Math.max(0, Math.min(fadeIn, fadeOut));
    ctx.globalAlpha = alpha;

    ctx.font = `800 52px ${this.fontFamily}`;
    ctx.fillStyle = "#ffffff";
    let title = scene.title;
    while (ctx.measureText(title).width > W - 200 && title.length > 3) {
      title = title.slice(0, -2);
    }
    ctx.fillText(title, 52, H - 158);

    this.drawSubtitle(scene.narration);

    ctx.globalAlpha = 1;

    // --- Fortschrittsbalken ---
    const totalP = (index + p) / total;
    ctx.fillStyle = "rgba(255,255,255,0.14)";
    ctx.fillRect(0, H - 7, W, 7);
    const grad = ctx.createLinearGradient(0, 0, W, 0);
    grad.addColorStop(0, "#8b5cf6");
    grad.addColorStop(0.6, "#d946ef");
    grad.addColorStop(1, "#fb923c");
    ctx.fillStyle = grad;
    ctx.fillRect(0, H - 7, W * totalP, 7);

    // --- Szenen-Übergänge (schwarz) ---
    const tr = Math.min(1, p / 0.05, (1 - p) / 0.05);
    ctx.fillStyle = `rgba(0,0,0,${(1 - Math.max(0, tr)).toFixed(3)})`;
    ctx.fillRect(0, 0, W, H);
  }

  private drawSubtitle(text: string) {
    const ctx = this.ctx;
    const maxWidth = W - 380;
    ctx.font = `500 30px ${this.fontFamily}`;
    const words = text.split(" ");
    const lines: string[] = [];
    let line = "";
    for (const w of words) {
      const test = line ? `${line} ${w}` : w;
      if (ctx.measureText(test).width > maxWidth && line) {
        lines.push(line);
        line = w;
      } else {
        line = test;
      }
    }
    if (line) lines.push(line);
    const show = lines.slice(0, 3);
    const lineH = 42;
    const boxH = show.length * lineH + 26;
    const y0 = H - 118 - (boxH - lineH);
    const boxW = Math.max(...show.map((l) => ctx.measureText(l).width)) + 56;
    const cx = W / 2;

    ctx.fillStyle = "rgba(3,3,10,0.62)";
    ctx.beginPath();
    this.roundRectPath(cx - boxW / 2, y0 - 34, boxW, boxH, 16);
    ctx.fill();

    ctx.fillStyle = "rgba(255,255,255,0.96)";
    ctx.textAlign = "center";
    show.forEach((l, i) => {
      ctx.fillText(l, cx, y0 + i * lineH);
    });
    ctx.textAlign = "left";
  }

  private roundRectPath(
    x: number,
    y: number,
    w: number,
    h: number,
    r: number,
  ) {
    const ctx = this.ctx;
    const rr = Math.min(r, w / 2, h / 2);
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
  }
}

export const VIDEO_SIZE = { width: W, height: H };
