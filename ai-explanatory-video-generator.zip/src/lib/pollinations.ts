// Pollinations.ai – komplett kostenlose APIs ohne Key.
export function pollinationsImageUrl(
  prompt: string,
  opts: { width?: number; height?: number; seed?: number } = {},
): string {
  const { width = 1280, height = 720, seed = 1 } = opts;
  const p = `${prompt}, no text, no words, no letters, no watermark, no logo, 16:9 composition`;
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(
    p,
  )}?width=${width}&height=${height}&seed=${seed}&nologo=true&model=flux&safe=true`;
}

export function pollinationsTtsUrl(text: string, voice = "nova"): string {
  const clean = text.replace(/\s+/g, " ").trim().slice(0, 600);
  return `https://text.pollinations.ai/${encodeURIComponent(
    clean,
  )}?model=openai-audio&voice=${encodeURIComponent(voice)}`;
}

// Lokale Proxy-URLs (verhindern Canvas-Tainting & CORS-Probleme)
export function proxyImageUrl(
  prompt: string,
  opts: { w?: number; h?: number; seed?: number } = {},
): string {
  const { w = 1280, h = 720, seed = 1 } = opts;
  return `/api/image?prompt=${encodeURIComponent(prompt)}&w=${w}&h=${h}&seed=${seed}`;
}

export function proxyTtsUrl(text: string, voice = "nova"): string {
  return `/api/tts?text=${encodeURIComponent(text)}&voice=${encodeURIComponent(
    voice,
  )}`;
}
