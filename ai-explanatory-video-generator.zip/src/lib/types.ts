export interface ScriptScene {
  title: string;
  narration: string;
  imagePrompt: string;
}

export interface ScriptResult {
  title: string;
  scenes: ScriptScene[];
}

export interface StudioScene extends ScriptScene {
  id: string;
  seed: number;
  imageStatus: "idle" | "loading" | "done" | "error";
  audioStatus: "idle" | "loading" | "done" | "error";
}

export const VOICES = [
  { id: "nova", label: "Nova · weiblich, warm" },
  { id: "shimmer", label: "Shimmer · weiblich, klar" },
  { id: "alloy", label: "Alloy · neutral, ruhig" },
  { id: "echo", label: "Echo · männlich, sanft" },
  { id: "onyx", label: "Onyx · männlich, tief" },
  { id: "fable", label: "Fable · erzählerisch" },
] as const;

export const STYLES = [
  {
    id: "cinematic",
    label: "Kinoreif",
    hint: "Dramatisches Licht, Film-Still",
    prompt:
      "cinematic film still, dramatic volumetric lighting, 35mm lens, shallow depth of field, rich color grading",
  },
  {
    id: "flat",
    label: "Flat-Illustration",
    hint: "Moderne Vektor-Ästhetik",
    prompt:
      "modern flat vector illustration, bold shapes, vibrant gradient palette, clean minimal composition",
  },
  {
    id: "watercolor",
    label: "Aquarell",
    hint: "Weiche künstlerische Malerei",
    prompt:
      "delicate watercolor painting, soft washes, visible paper texture, gentle pastel palette, hand painted",
  },
  {
    id: "render3d",
    label: "3D-Render",
    hint: "Weicher Pixar-Look",
    prompt:
      "high quality 3d render, pixar style, soft studio lighting, cute stylized materials, octane render, depth of field",
  },
  {
    id: "photo",
    label: "Fotorealistisch",
    hint: "Editorial-Fotografie",
    prompt:
      "photorealistic editorial photography, natural lighting, high detail, professional color grading, 50mm",
  },
  {
    id: "anime",
    label: "Anime",
    hint: "Makoto-Shinkai-Keyvisual",
    prompt:
      "beautiful anime key visual, makoto shinkai style, detailed background art, dramatic sky, vibrant lighting",
  },
] as const;

export function stylePrompt(styleId: string): string {
  return STYLES.find((s) => s.id === styleId)?.prompt ?? STYLES[0].prompt;
}

export function voiceLabel(id: string): string {
  return VOICES.find((v) => v.id === id)?.label ?? id;
}
