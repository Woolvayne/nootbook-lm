import type { ScriptResult, ScriptScene } from "@/lib/types";
import { stylePrompt } from "@/lib/types";

const MISTRAL_URL = "https://api.mistral.ai/v1/chat/completions";

function clampText(s: unknown, max: number): string {
  return String(s ?? "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
}

export function sanitizeScript(raw: unknown, sceneCount: number): ScriptResult {
  const obj = (raw ?? {}) as Record<string, unknown>;
  const scenesRaw = Array.isArray(obj.scenes) ? obj.scenes : [];
  const scenes: ScriptScene[] = scenesRaw
    .map((s) => {
      const o = (s ?? {}) as Record<string, unknown>;
      return {
        title: clampText(o.title, 80),
        narration: clampText(o.narration, 380),
        imagePrompt: clampText(o.imagePrompt ?? o.image_prompt, 400),
      };
    })
    .filter((s) => s.narration.length > 4 && s.imagePrompt.length > 4)
    .slice(0, sceneCount);
  if (scenes.length < 2) {
    throw new Error("Mistral hat kein verwertbares Drehbuch geliefert.");
  }
  return {
    title: clampText(obj.title, 90) || "Erklärvideo",
    scenes,
  };
}

export async function generateScript(params: {
  apiKey: string;
  topic: string;
  style: string;
  sceneCount: number;
  model?: string;
}): Promise<ScriptResult> {
  const { apiKey, topic, style, sceneCount } = params;
  const styleDesc = stylePrompt(style);

  const system = `Du bist ein preisgekrönter Drehbuchautor für kurze, hochwertige Erklärvideos im Stil von Kurzgesagt / NotebookLM.
Erstelle ein Drehbuch zum gegebenen Thema.

STRENGE REGELN:
- Exakt ${sceneCount} Szenen.
- Jede Szene hat:
  - "title": 2-5 Wörter auf Deutsch.
  - "narration": Der gesprochene Erzähltext auf Deutsch, 25-45 Wörter, MAXIMAL 320 Zeichen, natürlich und fesselnd, keine Aufzählungen, keine Sonderzeichen/Emojis, keine Kapitelmarker.
  - "imagePrompt": Eine detaillierte Bildbeschreibung auf ENGLISCH für ein KI-Bildmodell. Stil: ${styleDesc}. Beschreibe Szene, Motiv, Farben, Licht und Stimmung konkret. NIEMALS Text, Buchstaben, Logos oder Wasserzeichen im Bild.
- Szene 1 ist ein Hook (überraschende Frage oder These). Die letzte Szene ist ein starkes Fazit oder Ausblick.
- Antworte AUSSCHLIESSLICH mit valideem JSON in dieser Form:
{"title": "Filmtitel auf Deutsch", "scenes": [{"title": "...", "narration": "...", "imagePrompt": "..."}]}`;

  const res = await fetch(MISTRAL_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: params.model ?? "mistral-small-latest",
      messages: [
        { role: "system", content: system },
        { role: "user", content: `Thema: ${topic}` },
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    }),
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    if (res.status === 401) throw new Error("Ungültiger Mistral API-Schlüssel.");
    throw new Error(
      `Mistral-Fehler (${res.status}): ${detail.slice(0, 200)}`,
    );
  }

  const data = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const content = data.choices?.[0]?.message?.content ?? "";
  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    throw new Error("Antwort von Mistral war kein valides JSON.");
  }
  return sanitizeScript(parsed, sceneCount);
}

export async function verifyMistralKey(apiKey: string): Promise<boolean> {
  const res = await fetch("https://api.mistral.ai/v1/models", {
    headers: { Authorization: `Bearer ${apiKey}` },
    cache: "no-store",
  });
  return res.ok;
}
