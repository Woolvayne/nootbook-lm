import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { apiKeys, projects, scenes, settings } from "@/db/schema";
import { generateScript } from "@/lib/mistral";
import { proxyImageUrl, proxyTtsUrl } from "@/lib/pollinations";

export const maxDuration = 120;

async function authenticate(req: Request): Promise<boolean> {
  const key = req.headers.get("x-api-key") ?? "";
  if (!key) return false;
  const rows = await db
    .select({ id: apiKeys.id })
    .from(apiKeys)
    .where(eq(apiKeys.key, key))
    .limit(1);
  return rows.length > 0;
}

/**
 * Externer Endpunkt für KI-Assistenten (Custom GPTs, Claude, LangChain ...).
 * POST /api/v1/generate
 * Header: x-api-key (Narrato-Key), optional x-mistral-key (eigener Mistral-Key)
 * Body: { topic, style?, voice?, sceneCount? }
 */
export async function POST(req: Request) {
  if (!(await authenticate(req))) {
    return NextResponse.json(
      {
        error: "Unauthorized. Sende einen gültigen Narrato API-Key im Header 'x-api-key'.",
      },
      { status: 401 },
    );
  }

  try {
    const body = (await req.json()) as {
      topic?: string;
      style?: string;
      voice?: string;
      sceneCount?: number;
    };
    const topic = String(body.topic ?? "").trim();
    if (topic.length < 3) {
      return NextResponse.json(
        { error: "topic ist erforderlich (mindestens 3 Zeichen)." },
        { status: 400 },
      );
    }

    let mistralKey = (req.headers.get("x-mistral-key") ?? "").trim();
    if (!mistralKey) {
      const rows = await db
        .select()
        .from(settings)
        .where(eq(settings.key, "mistral_api_key"))
        .limit(1);
      mistralKey = rows[0]?.value ?? "";
    }
    if (!mistralKey) {
      return NextResponse.json(
        {
          error:
            "Kein Mistral-Schlüssel konfiguriert. Entweder im Narrato-Dashboard hinterlegen oder als Header 'x-mistral-key' mitsenden.",
        },
        { status: 400 },
      );
    }

    const style = String(body.style ?? "cinematic");
    const voice = String(body.voice ?? "nova");
    const sceneCount = Math.min(Math.max(Number(body.sceneCount) || 5, 3), 8);

    const script = await generateScript({
      apiKey: mistralKey,
      topic,
      style,
      sceneCount,
    });

    const seeds = script.scenes.map(
      (_, i) => 1000 + Math.floor(Math.random() * 900_000) + i * 7,
    );

    const [project] = await db
      .insert(projects)
      .values({ title: script.title, topic, style, voice })
      .returning();
    await db.insert(scenes).values(
      script.scenes.map((s, i) => ({
        projectId: project.id,
        position: i,
        title: s.title,
        narration: s.narration,
        imagePrompt: s.imagePrompt,
        seed: seeds[i],
      })),
    );

    const origin = new URL(req.url).origin;
    return NextResponse.json({
      projectId: project.id,
      title: script.title,
      topic,
      style,
      voice,
      studioUrl: `${origin}/studio?project=${project.id}`,
      scenes: script.scenes.map((s, i) => ({
        index: i,
        title: s.title,
        narration: s.narration,
        imagePrompt: s.imagePrompt,
        assets: {
          image: `${origin}${proxyImageUrl(s.imagePrompt, { seed: seeds[i] })}`,
          audio: `${origin}${proxyTtsUrl(s.narration, voice)}`,
        },
      })),
      note: "Bilder & Audio werden on-demand von Pollinations generiert (kostenlos). Die finale Videomontage erfolgt im Narrato Studio (Browser).",
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Serverfehler" },
      { status: 500 },
    );
  }
}
