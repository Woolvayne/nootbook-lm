import { NextResponse } from "next/server";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { apiKeys, projects, scenes } from "@/db/schema";

/**
 * GET /api/v1/projects – Liste der Projekte für KI-Assistenten.
 * Header: x-api-key
 */
export async function GET(req: Request) {
  const key = req.headers.get("x-api-key") ?? "";
  if (!key) {
    return NextResponse.json({ error: "x-api-key fehlt." }, { status: 401 });
  }
  const rows = await db
    .select({ id: apiKeys.id })
    .from(apiKeys)
    .where(eq(apiKeys.key, key))
    .limit(1);
  if (rows.length === 0) {
    return NextResponse.json({ error: "Ungültiger API-Key." }, { status: 401 });
  }

  const list = await db
    .select({
      id: projects.id,
      title: projects.title,
      topic: projects.topic,
      style: projects.style,
      voice: projects.voice,
      createdAt: projects.createdAt,
      sceneCount: sql<number>`count(${scenes.id})::int`,
    })
    .from(projects)
    .leftJoin(scenes, sql`${scenes.projectId} = ${projects.id}`)
    .groupBy(projects.id)
    .orderBy(desc(projects.createdAt))
    .limit(50);
  return NextResponse.json({ projects: list });
}
