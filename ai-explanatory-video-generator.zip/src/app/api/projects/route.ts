import { NextResponse } from "next/server";
import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { projects, scenes } from "@/db/schema";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: projects.id,
        title: projects.title,
        topic: projects.topic,
        style: projects.style,
        voice: projects.voice,
        createdAt: projects.createdAt,
        sceneCount: sql<number>`count(${scenes.id})::int`,
      })
      .from(projects)
      .leftJoin(scenes, sql`${scenes.projectId} = ${projects.id}`)
      .groupBy(projects.id)
      .orderBy(desc(projects.createdAt))
      .limit(50);
    return NextResponse.json({ projects: rows });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "DB-Fehler" },
      { status: 500 },
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      title?: string;
      topic?: string;
      style?: string;
      voice?: string;
      scenes?: {
        title: string;
        narration: string;
        imagePrompt: string;
        seed?: number;
      }[];
    };
    const topic = String(body.topic ?? "").trim();
    const title = String(body.title ?? "").trim() || "Ohne Titel";
    const list = Array.isArray(body.scenes) ? body.scenes : [];
    if (!topic || list.length === 0) {
      return NextResponse.json(
        { error: "Thema und Szenen sind erforderlich." },
        { status: 400 },
      );
    }

    const [project] = await db
      .insert(projects)
      .values({
        title: title.slice(0, 120),
        topic: topic.slice(0, 500),
        style: String(body.style ?? "cinematic").slice(0, 40),
        voice: String(body.voice ?? "nova").slice(0, 24),
      })
      .returning();

    await db.insert(scenes).values(
      list.slice(0, 12).map((s, i) => ({
        projectId: project.id,
        position: i,
        title: String(s.title ?? "").slice(0, 120),
        narration: String(s.narration ?? "").slice(0, 500),
        imagePrompt: String(s.imagePrompt ?? "").slice(0, 500),
        seed: Math.max(Number(s.seed) || 1, 1),
      })),
    );

    return NextResponse.json({ id: project.id });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "DB-Fehler" },
      { status: 500 },
    );
  }
}
