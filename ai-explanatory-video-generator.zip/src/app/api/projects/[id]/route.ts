import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { projects, scenes } from "@/db/schema";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const [project] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, id))
      .limit(1);
    if (!project) {
      return NextResponse.json(
        { error: "Projekt nicht gefunden." },
        { status: 404 },
      );
    }
    const sceneRows = await db
      .select()
      .from(scenes)
      .where(eq(scenes.projectId, id))
      .orderBy(asc(scenes.position));
    return NextResponse.json({ project, scenes: sceneRows });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "DB-Fehler" },
      { status: 500 },
    );
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const body = (await req.json()) as {
      title?: string;
      style?: string;
      voice?: string;
      scenes?: {
        title: string;
        narration: string;
        imagePrompt: string;
        seed?: number;
      }[];
    };

    await db
      .update(projects)
      .set({
        ...(body.title ? { title: body.title.slice(0, 120) } : {}),
        ...(body.style ? { style: body.style.slice(0, 40) } : {}),
        ...(body.voice ? { voice: body.voice.slice(0, 24) } : {}),
        updatedAt: new Date(),
      })
      .where(eq(projects.id, id));

    if (Array.isArray(body.scenes)) {
      await db.delete(scenes).where(eq(scenes.projectId, id));
      await db.insert(scenes).values(
        body.scenes.slice(0, 12).map((s, i) => ({
          projectId: id,
          position: i,
          title: String(s.title ?? "").slice(0, 120),
          narration: String(s.narration ?? "").slice(0, 500),
          imagePrompt: String(s.imagePrompt ?? "").slice(0, 500),
          seed: Math.max(Number(s.seed) || 1, 1),
        })),
      );
    }
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "DB-Fehler" },
      { status: 500 },
    );
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    await db.delete(projects).where(eq(projects.id, id));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "DB-Fehler" },
      { status: 500 },
    );
  }
}
